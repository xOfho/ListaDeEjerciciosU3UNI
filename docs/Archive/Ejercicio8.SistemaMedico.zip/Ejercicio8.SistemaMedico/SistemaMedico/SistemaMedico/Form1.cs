﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SistemaMedico
{
    public partial class Form1 : Form
    {
        
        PacienteDAL dal = new PacienteDAL();

        public Form1()
        {
            InitializeComponent();
        }

        
        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            var nuevoPaciente = new Paciente
            {
                Nombre = txtNombre.Text,
                Edad = int.Parse(txtEdad.Text),
                Diagnostico = txtDiagnostico.Text
            };

            dal.Registrar(nuevoPaciente);
            MessageBox.Show("Paciente Guardado");
            CargarGrid(); // Refrescar la lista
        }

        
        private void btnBuscar_Click(object sender, EventArgs e)
        {
           
            dgvPacientes.DataSource = dal.Listar(txtBuscar.Text, false);
        }

        
        private void btnMayores60_Click(object sender, EventArgs e)
        {
            
            dgvPacientes.DataSource = dal.Listar(null, true);
        }

        
        private void CargarGrid()
        {
            dgvPacientes.DataSource = dal.Listar();
        }
    }
}