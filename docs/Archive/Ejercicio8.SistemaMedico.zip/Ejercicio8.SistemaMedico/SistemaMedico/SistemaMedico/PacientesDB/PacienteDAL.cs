﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SistemaMedico
{
    public class PacienteDAL
    {
        private string connectionString = @"Server=DESKTOP-1SQSI5J\SQLEXPRESS;Database=SistemaMedicoBD;Trusted_Connection=True;TrustServerCertificate=True;";
        public void Registrar(Paciente p)
        {
            using (var con = new SqlConnection(connectionString))
            {
                string sql = "INSERT INTO Pacientes (Nombre, Edad, Diagnostico) VALUES (@nom, @ed, @diag)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@nom", p.Nombre);
                cmd.Parameters.AddWithValue("@ed", p.Edad);
                cmd.Parameters.AddWithValue("@diag", p.Diagnostico);
                con.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public List<Paciente> Listar(string filtroNombre = null, bool soloMayores60 = false)
        {
            var lista = new List<Paciente>();
            using (var con = new SqlConnection(connectionString))
            {
                string sql = "SELECT * FROM Pacientes WHERE 1=1";
                if (!string.IsNullOrEmpty(filtroNombre)) sql += " AND Nombre LIKE @nom";
                if (soloMayores60) sql += " AND Edad > 60";

                SqlCommand cmd = new SqlCommand(sql, con);
                if (!string.IsNullOrEmpty(filtroNombre)) cmd.Parameters.AddWithValue("@nom", "%" + filtroNombre + "%");

                con.Open();
                using (var rdr = cmd.ExecuteReader())
                {
                    while (rdr.Read())
                    {
                        lista.Add(new Paciente
                        {
                            Id = (int)rdr["Id"],
                            Nombre = rdr["Nombre"].ToString(),
                            Edad = (int)rdr["Edad"],
                            Diagnostico = rdr["Diagnostico"].ToString()
                        });
                    }
                }
            }
            return lista;
        }
    }   
}