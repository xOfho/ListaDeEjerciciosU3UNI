﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Data.SqlClient;

namespace Registro_de_clientes.Datos
{
    public class AppDbContext 
    {
        private string cadena = "Data Source=JOLETTEOLIVAS;Initial Catalog=BD_Cliente;Integrated Security=True;Encrypt=True;TrustServerCertificate=True";

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(cadena);
        }
    }
}
