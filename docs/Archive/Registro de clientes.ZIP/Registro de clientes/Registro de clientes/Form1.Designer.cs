﻿
namespace Registro_de_clientes
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            textNombre = new TextBox();
            textTelefono = new TextBox();
            textCorreo = new TextBox();
            label1 = new Label();
            btnEliminar = new Button();
            btnInsertar = new Button();
            dgvClient = new DataGridView();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)dgvClient).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // textNombre
            // 
            textNombre.Font = new Font("Berlin Sans FB", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textNombre.Location = new Point(100, 49);
            textNombre.Multiline = true;
            textNombre.Name = "textNombre";
            textNombre.Size = new Size(202, 30);
            textNombre.TabIndex = 0;
            textNombre.Text = "Nombre";
            textNombre.TextChanged += textNombre_TextChanged;
            // 
            // textTelefono
            // 
            textTelefono.Font = new Font("Berlin Sans FB", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textTelefono.Location = new Point(100, 121);
            textTelefono.Multiline = true;
            textTelefono.Name = "textTelefono";
            textTelefono.Size = new Size(202, 30);
            textTelefono.TabIndex = 1;
            textTelefono.Text = "Teléfono";
            // 
            // textCorreo
            // 
            textCorreo.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            textCorreo.Font = new Font("Berlin Sans FB", 11.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            textCorreo.Location = new Point(100, 85);
            textCorreo.Multiline = true;
            textCorreo.Name = "textCorreo";
            textCorreo.Size = new Size(202, 30);
            textCorreo.TabIndex = 2;
            textCorreo.Text = "Correo";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(55, 28);
            label1.Name = "label1";
            label1.Size = new Size(0, 15);
            label1.TabIndex = 3;
            label1.Click += label1_Click;
            // 
            // btnEliminar
            // 
            btnEliminar.Font = new Font("Berlin Sans FB", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnEliminar.Location = new Point(196, 195);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(106, 39);
            btnEliminar.TabIndex = 6;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click_1;
            // 
            // btnInsertar
            // 
            btnInsertar.Font = new Font("Berlin Sans FB", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnInsertar.Location = new Point(64, 195);
            btnInsertar.Name = "btnInsertar";
            btnInsertar.Size = new Size(106, 39);
            btnInsertar.TabIndex = 7;
            btnInsertar.Text = "Agregar";
            btnInsertar.UseVisualStyleBackColor = true;
            btnInsertar.Click += btnAgregar_Click;
            // 
            // dgvClient
            // 
            dgvClient.BackgroundColor = SystemColors.GradientInactiveCaption;
            dgvClient.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvClient.Location = new Point(340, 49);
            dgvClient.Name = "dgvClient";
            dgvClient.Size = new Size(353, 180);
            dgvClient.TabIndex = 8;
            dgvClient.CellContentClick += dgvClient_CellContentClick;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = SystemColors.Window;
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(66, 49);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(37, 30);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 10;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.BackColor = SystemColors.Window;
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(66, 85);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(37, 30);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 11;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackColor = SystemColors.Window;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(66, 121);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(37, 30);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 12;
            pictureBox3.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(717, 450);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(pictureBox1);
            Controls.Add(dgvClient);
            Controls.Add(btnInsertar);
            Controls.Add(btnEliminar);
            Controls.Add(label1);
            Controls.Add(textCorreo);
            Controls.Add(textTelefono);
            Controls.Add(textNombre);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvClient).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void btnEliminar_Click_1(object sender, EventArgs e)
        {

            if (dgvClient.CurrentRow == null)
            {
                MessageBox.Show("No hay ningún cliente seleccionado para eliminar.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            if (dgvClient.CurrentRow != null)
            {
                int id = int.Parse(dgvClient.CurrentRow.Cells["Id"].Value.ToString());
                _repo.Eliminar(id);
                CargarDatos();
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        { }

        #endregion

        private TextBox textNombre;
        private TextBox textTelefono;
        private TextBox textCorreo;
        private Label label1;
        private Button btnEliminar;
        private Button btnInsertar;
        private DataGridView dgvClient;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
    }
}
