using Microsoft.Data.SqlClient;
using Registro_de_clientes.Modelos;
using Registro_de_clientes.Repositorio;
using System.Drawing;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Registro_de_clientes
{
    public partial class Form1 : Form
    {
        ClienteRepository _repo = new ClienteRepository();
        public Form1()
        {
            InitializeComponent();
            CargarDatos();
        }
        private void CargarDatos()
        {
            dgvClient.DataSource = null;
            dgvClient.DataSource = _repo.ObtenerTodos();
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
           
            Cliente c = new Cliente()
            {
                Nombre = textNombre.Text,
                Telefono = textTelefono.Text,
                Correo = textCorreo.Text
            };

            if (string.IsNullOrWhiteSpace(textNombre.Text) ||
            string.IsNullOrWhiteSpace(textTelefono.Text) ||
            string.IsNullOrWhiteSpace(textCorreo.Text))
            {
                MessageBox.Show("Por favor, completa todos los campos requeridos.",
                                "Campos incompletos",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }

            if (!(textCorreo.Text.EndsWith("@gmail.com")))
            {
                MessageBox.Show("Correo iv�lido.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(textTelefono.Text, @"^\+?\d+$"))
            {
                MessageBox.Show("El tel�fono solo puede contener n�meros.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            if (!System.Text.RegularExpressions.Regex.IsMatch(textNombre.Text, @"^[a-zA-Z\s]+$"))
            {
                MessageBox.Show("El nombre solo puede contener letras y espacios.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Error);
                return;
            }

            textNombre.Clear();
            textCorreo.Clear();
            textTelefono.Clear();

            _repo.Insertar(c);
            CargarDatos();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {

            if (dgvClient.CurrentRow == null)
            {
                MessageBox.Show("No hay ning�n cliente seleccionado para eliminar.",
                                "Error",
                                MessageBoxButtons.OK,
                                MessageBoxIcon.Warning);
                return;
            }
            if (dgvClient.CurrentRow != null)
            {
                int id = int.Parse(dgvClient.CurrentRow.Cells["Id"].Value.ToString());

                _repo.Eliminar(id);
                CargarDatos();

            }
            ;
        }

        private void dgvClient_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textNombre_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
