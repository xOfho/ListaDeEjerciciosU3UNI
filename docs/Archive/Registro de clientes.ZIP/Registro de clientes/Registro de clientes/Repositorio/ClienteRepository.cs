﻿using Microsoft.Data.SqlClient;
using Registro_de_clientes.Datos;
using Registro_de_clientes.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Runtime.Intrinsics.Arm;
using System.Text;
using System.Threading.Tasks;

namespace Registro_de_clientes.Repositorio
{
    public class ClienteRepository : IClienteRepository
    {
        private readonly AppDbContext _conexion = new AppDbContext();

        public List<Cliente> ObtenerTodos()
        {
            List<Cliente> lista = new List<Cliente>();

            using (SqlConnection conn = _conexion.ObtenerConexion())
            {
                conn.Open();

                using SqlCommand cmd = new SqlCommand("SELECT * FROM Client", conn);
                using SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    lista.Add(new Cliente
                    {
                        Id = (int)reader["Id"],
                        Nombre = reader["Nombre"].ToString(),
                        Telefono = reader["Telefono"].ToString(),
                        Correo = reader["Correo"].ToString(),
                    });
                }
            }
            return lista;
        } 
        public void Insertar(Cliente client)
        {
            using (SqlConnection conn = _conexion.ObtenerConexion())
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO Client(Nombre, Telefono, Correo) VALUES(@Nombre,@Telefono,@Correo)", conn);

                cmd.Parameters.AddWithValue("@Nombre", client.Nombre);
                cmd.Parameters.AddWithValue("@Telefono", client.Telefono);
                cmd.Parameters.AddWithValue("@Correo", client.Correo);

                cmd.ExecuteNonQuery();
            }
        }

        public void Eliminar(int id)
        {
            using (SqlConnection conn = _conexion.ObtenerConexion())
            {
                conn.Open();

                SqlCommand cmd = new SqlCommand("DELETE FROM Client WHERE Id=@Id", conn);
                cmd.Parameters.AddWithValue("@Id", id);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
