﻿using Registro_de_clientes.Modelos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Registro_de_clientes.Repositorio
{
    public interface IClienteRepository
    {
        List<Cliente> ObtenerTodos();
        void Insertar(Cliente cliente);
        void Eliminar(int id);

    }
}
